import UserList from "./components/UserList";

function App() {
  return <UserList />;
}

export default App;
